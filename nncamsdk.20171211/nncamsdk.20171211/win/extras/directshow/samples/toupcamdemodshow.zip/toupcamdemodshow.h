#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols

class CtoupcamdemodshowApp : public CWinApp
{
public:
	CtoupcamdemodshowApp();
public:
	virtual BOOL InitInstance();
public:
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CtoupcamdemodshowApp theApp;
