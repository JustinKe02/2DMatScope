#define STRICT
#define VC_EXTRALEAN
#include <atlbase.h>
#include <atlwin.h>
#include <atlapp.h>
CAppModule _Module;
#include <windows.h>
#include <shlobj.h>
#include <shlwapi.h>
#include <stdio.h>
#include <stdlib.h>
#include <atlctrls.h>
#include <atlframe.h>
#include <atlcrack.h>
#include <atldlgs.h>
#include "toupcam.h"
#ifdef _USE_TOUPCAMPROP_
#include "toupcamprop.h"
#endif
#include "resource.h"
#include <sstream>
#include <iomanip>
#include <InitGuid.h>
#include <wincodec.h>
#include <wmsdkidl.h>

#define MSG_CAMEVENT			(WM_APP + 1)

class CMainFrame;

static BOOL SaveImageBmp(const wchar_t* strFilename, const void* pData, const BITMAPINFOHEADER* pHeader)
{
	FILE* fp = _wfopen(strFilename, L"wb");
	if (fp)
	{
		BITMAPFILEHEADER fheader = { 0 };
		fheader.bfType = 0x4d42;
		fheader.bfSize = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + pHeader->biSizeImage;
		fheader.bfOffBits = (DWORD)(sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER));
		fwrite(&fheader, sizeof(fheader), 1, fp);
		fwrite(pHeader, 1, sizeof(BITMAPINFOHEADER), fp);
		fwrite(pData, 1, pHeader->biSizeImage, fp);
		fclose(fp);
		return TRUE;
	}
	return FALSE;
}

static BOOL SaveImageByWIC(const wchar_t* strFilename, const void* pData, const BITMAPINFOHEADER* pHeader)
{
	GUID guidContainerFormat;
	if (PathMatchSpec(strFilename, L"*.jpg"))
		guidContainerFormat = GUID_ContainerFormatJpeg;
	else if (PathMatchSpec(strFilename, L"*.png"))
		guidContainerFormat = GUID_ContainerFormatPng;
	else
		return FALSE;

	CComPtr<IWICImagingFactory> spIWICImagingFactory;
	HRESULT hr = CoCreateInstance(CLSID_WICImagingFactory, NULL, CLSCTX_INPROC_SERVER, __uuidof(IWICImagingFactory), (LPVOID*)&spIWICImagingFactory);
	if (FAILED(hr))
		return FALSE;

	CComPtr<IWICBitmapEncoder> spIWICBitmapEncoder;
	hr = spIWICImagingFactory->CreateEncoder(guidContainerFormat, NULL, &spIWICBitmapEncoder);
	if (FAILED(hr))
		return FALSE;

	CComPtr<IWICStream> spIWICStream;
	spIWICImagingFactory->CreateStream(&spIWICStream);
	if (FAILED(hr))
		return FALSE;

	hr = spIWICStream->InitializeFromFilename(strFilename, GENERIC_WRITE);
	if (FAILED(hr))
		return FALSE;

	hr = spIWICBitmapEncoder->Initialize(spIWICStream, WICBitmapEncoderNoCache);
	if (FAILED(hr))
		return FALSE;

	CComPtr<IWICBitmapFrameEncode> spIWICBitmapFrameEncode;
	CComPtr<IPropertyBag2> spIPropertyBag2;
	hr = spIWICBitmapEncoder->CreateNewFrame(&spIWICBitmapFrameEncode, &spIPropertyBag2);
	if (FAILED(hr))
		return FALSE;

	if (GUID_ContainerFormatJpeg == guidContainerFormat)
	{
		PROPBAG2 option = { 0 };
		option.pstrName = L"ImageQuality"; /* jpg quality, you can change this setting */
		CComVariant varValue(0.75f);
		spIPropertyBag2->Write(1, &option, &varValue);
	}
	hr = spIWICBitmapFrameEncode->Initialize(spIPropertyBag2);
	if (FAILED(hr))
		return FALSE;

	hr = spIWICBitmapFrameEncode->SetSize(pHeader->biWidth, pHeader->biHeight);
	if (FAILED(hr))
		return FALSE;

	WICPixelFormatGUID formatGUID = GUID_WICPixelFormat24bppBGR;
	hr = spIWICBitmapFrameEncode->SetPixelFormat(&formatGUID);
	if (FAILED(hr))
		return FALSE;

	LONG nWidthBytes = TDIBWIDTHBYTES(pHeader->biWidth * pHeader->biBitCount);
	for (LONG i = 0; i < pHeader->biHeight; ++i)
	{
		hr = spIWICBitmapFrameEncode->WritePixels(1, nWidthBytes, nWidthBytes, ((BYTE*)pData) + nWidthBytes * (pHeader->biHeight - i - 1));
		if (FAILED(hr))
			return FALSE;
	}

	hr = spIWICBitmapFrameEncode->Commit();
	if (FAILED(hr))
		return FALSE;
	hr = spIWICBitmapEncoder->Commit();
	if (FAILED(hr))
		return FALSE;
	
	return TRUE;
}

class CExposureTimeDlg : public CDialogImpl<CExposureTimeDlg>
{
	HToupCam	m_hToupCam;
public:
	enum { IDD = IDD_EXPOSURETIME };

	CExposureTimeDlg(HToupCam hToupCam)
	: m_hToupCam(hToupCam)
	{
	}

	BEGIN_MSG_MAP(CExposureTimeDlg)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		COMMAND_ID_HANDLER(IDOK, OnOK)
		COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
	END_MSG_MAP()

	LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		CenterWindow(GetParent());

		unsigned nMin = 0, nMax = 0, nDef = 0, nTime = 0;
		if (SUCCEEDED(Toupcam_get_ExpTimeRange(m_hToupCam, &nMin, &nMax, &nDef)))
		{
			CTrackBarCtrl ctrl(GetDlgItem(IDC_SLIDER1));
			ctrl.SetRangeMin(nMin);
			ctrl.SetRangeMax(nMax);

			if (SUCCEEDED(Toupcam_get_ExpoTime(m_hToupCam, &nTime)))
				ctrl.SetPos(nTime);
		}
		
		return TRUE;
	}

	LRESULT OnOK(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		CTrackBarCtrl ctrl(GetDlgItem(IDC_SLIDER1));
		Toupcam_put_ExpoTime(m_hToupCam, ctrl.GetPos());

		EndDialog(wID);
		return 0;
	}

	LRESULT OnCancel(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		EndDialog(wID);
		return 0;
	}
};

class CLedDlg : public CDialogImpl<CLedDlg>
{
	HToupCam	m_hToupCam;
public:
	enum { IDD = IDD_LED };

	CLedDlg(HToupCam hToupCam)
	: m_hToupCam(hToupCam)
	{
	}

	BEGIN_MSG_MAP(CLedDlg)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		COMMAND_ID_HANDLER(IDC_BUTTON1, OnButton1)
		COMMAND_ID_HANDLER(IDC_BUTTON2, OnButton2)
		COMMAND_ID_HANDLER(IDC_BUTTON3, OnButton3)
		COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
	END_MSG_MAP()

	LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		CenterWindow(GetParent());
		return TRUE;
	}

	LRESULT OnButton1(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		UINT nIndex = GetDlgItemInt(IDC_EDIT1);
		Toupcam_put_LEDState(m_hToupCam, nIndex, 1, 0);
		return 0;
	}

	LRESULT OnButton2(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		UINT nIndex = GetDlgItemInt(IDC_EDIT1);
		UINT nPeriod = GetDlgItemInt(IDC_EDIT2);
		Toupcam_put_LEDState(m_hToupCam, nIndex, 2, nPeriod);
		return 0;
	}

	LRESULT OnButton3(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		UINT nIndex = GetDlgItemInt(IDC_EDIT1);
		Toupcam_put_LEDState(m_hToupCam, nIndex, 0, 0);
		return 0;
	}

	LRESULT OnCancel(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		EndDialog(wID);
		return 0;
	}
};

class CBitdepthDlg : public CDialogImpl<CBitdepthDlg>
{
	HToupCam	m_hToupCam;
public:
	enum { IDD = IDD_BITDEPTH };

	CBitdepthDlg(HToupCam hToupCam)
	: m_hToupCam(hToupCam)
	{
	}

	BEGIN_MSG_MAP(CBitdepthDlg)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		COMMAND_ID_HANDLER(IDC_RADIO1, OnRadio1)
		COMMAND_ID_HANDLER(IDC_RADIO2, OnRadio2)
		COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
	END_MSG_MAP()

	LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		CenterWindow(GetParent());

		int bits = Toupcam_get_MaxBitDepth(m_hToupCam);
		if (bits <= 8)
		{
			GetDlgItem(IDC_RADIO2).EnableWindow(FALSE);
			CheckDlgButton(IDC_RADIO1, 1);
		}
		else
		{
			TCHAR str[16];
			_stprintf(str, _T("%d Bits"), bits);
			GetDlgItem(IDC_RADIO2).SetWindowText(str);

			int value = 0;
			Toupcam_get_Option(m_hToupCam, TOUPCAM_OPTION_BITDEPTH, &value);
			CheckDlgButton(IDC_RADIO1, (0 == value) ? 1 : 0);
			CheckDlgButton(IDC_RADIO2, value ? 1 : 0);
		}
		return TRUE;
	}

	LRESULT OnRadio1(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		Toupcam_put_Option(m_hToupCam, TOUPCAM_OPTION_BITDEPTH, 0);
		return 0;
	}

	LRESULT OnRadio2(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		Toupcam_put_Option(m_hToupCam, TOUPCAM_OPTION_BITDEPTH, 1);
		return 0;
	}

	LRESULT OnCancel(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		EndDialog(wID);
		return 0;
	}
};

class CRoiDlg : public CDialogImpl<CRoiDlg>
{
public:
	enum { IDD = IDD_ROI };

	unsigned xOffset_;
	unsigned yOffset_;
	unsigned xWidth_;
	unsigned yHeight_;

	CRoiDlg()
	{
	}

	BEGIN_MSG_MAP(CRoiDlg)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		COMMAND_ID_HANDLER(IDOK, OnOK)
		COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
	END_MSG_MAP()

	LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		CenterWindow(GetParent());

		SetDlgItemInt(IDC_EDIT1, xOffset_);
		SetDlgItemInt(IDC_EDIT2, yOffset_);
		SetDlgItemInt(IDC_EDIT3, xWidth_);
		SetDlgItemInt(IDC_EDIT4, yHeight_);
		return TRUE;
	}

	LRESULT OnOK(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		xOffset_ = GetDlgItemInt(IDC_EDIT1);
		yOffset_ = GetDlgItemInt(IDC_EDIT2);
		xWidth_ = GetDlgItemInt(IDC_EDIT3);
		yHeight_ = GetDlgItemInt(IDC_EDIT4);

		EndDialog(wID);
		return 0;
	}

	LRESULT OnCancel(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		EndDialog(wID);
		return 0;
	}
};

class CTriggerNumberDlg : public CDialogImpl<CTriggerNumberDlg>
{
public:
	enum { IDD = IDD_TRIGGERNUMBER };

	unsigned number_;

	CTriggerNumberDlg() : number_(1)
	{
	}

	BEGIN_MSG_MAP(CTriggerNumberDlg)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		COMMAND_ID_HANDLER(IDOK, OnOK)
		COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
	END_MSG_MAP()

	LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		CenterWindow(GetParent());

		SetDlgItemInt(IDC_EDIT1, number_);
		return TRUE;
	}

	LRESULT OnOK(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		number_ = GetDlgItemInt(IDC_EDIT1);
		if ((0 == number_) || (number_ >= SHRT_MAX))
		{
			AtlMessageBox(m_hWnd, L"Invalid number");
			return 0;
		}

		EndDialog(wID);
		return 0;
	}

	LRESULT OnCancel(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		EndDialog(wID);
		return 0;
	}
};

class CEEPROMDlg : public CDialogImpl<CEEPROMDlg>
{
	HToupCam	m_hToupCam;
public:
	enum { IDD = IDD_EEPROM };

	CEEPROMDlg(HToupCam hToupCam)
	: m_hToupCam(hToupCam)
	{
	}

	BEGIN_MSG_MAP(CEEPROMDlg)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		COMMAND_ID_HANDLER(IDC_BUTTON1, OnButton1)
		COMMAND_ID_HANDLER(IDC_BUTTON2, OnButton2)
		COMMAND_ID_HANDLER(IDC_BUTTON3, OnButton3)
		COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
	END_MSG_MAP()

	LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		CenterWindow(GetParent());
		return TRUE;
	}

	LRESULT OnButton1(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		TCHAR strAddr[64] = { 0 }, strLength[64] = { 0 };
		if (GetDlgItemText(IDC_EDIT1, strAddr, _countof(strAddr)) && GetDlgItemText(IDC_EDIT2, strLength, _countof(strLength)))
		{
			TCHAR* endptr = NULL;
			unsigned uAddr = _tcstoul(strAddr, &endptr, 16);
			unsigned uLength = _tcstoul(strLength, &endptr, 16);
			if (uLength)
			{
				unsigned char* tmpBuffer = (unsigned char*)alloca(uLength);
				HRESULT hr = Toupcam_read_EEPROM(m_hToupCam, uAddr, tmpBuffer, uLength);
				if (FAILED(hr))
					AtlMessageBox(m_hWnd, _T("Failed to read EEPROM."));
				else if (0 == hr)
					AtlMessageBox(m_hWnd, _T("Read EEPROM, 0 byte."));
				else if (hr > 0)
				{
					std::wstringstream wstr;
					wstr << _T("EEPROM: length = ") << hr << _T(", data = ");
					for (int i = 0; i < hr; ++i)
						wstr << std::hex << std::setw(2) << std::setfill((TCHAR)'0') << tmpBuffer[i] << _T(" ");
					AtlMessageBox(m_hWnd, wstr.str().c_str());
				}
			}
		}
		return 0;
	}

	LRESULT OnButton2(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		TCHAR strAddr[64] = { 0 }, strLength[64] = { 0 }, strData[1024] = { 0 };
		if (GetDlgItemText(IDC_EDIT1, strAddr, _countof(strAddr)) && GetDlgItemText(IDC_EDIT2, strLength, _countof(strLength)) && GetDlgItemText(IDC_EDIT3, strData, _countof(strData)))
		{
			TCHAR* endptr = NULL;
			unsigned uAddr = _tcstoul((LPCTSTR)strAddr, &endptr, 16);
			unsigned uLength = _tcstoul((LPCTSTR)strLength, &endptr, 16);
			if (uLength)
			{
				unsigned char* tmpBuffer = (unsigned char*)alloca(uLength);
				memset(tmpBuffer, 0, uLength);
				for (size_t i = 0; i < _countof(strData); i += 2)
				{
					if ('\0' == strData[0])
						break;
					if (strData[i] >= '0' && strData[i] <= '9')
						tmpBuffer[i / 2] = (strData[i] - '0') << 4;
					else if (strData[i] >= 'a' && strData[i] <= 'f')
						tmpBuffer[i / 2] = (strData[i] - 'a' + 10) << 4;
					else if (strData[i] >= 'A' && strData[i] <= 'F')
						tmpBuffer[i / 2] = (strData[i] - 'A' + 10) << 4;
					if (strData[i + 1] >= '0' && strData[i + 1] <= '9')
						tmpBuffer[i / 2] |= (strData[i + 1] - '0');
					else if (strData[i + 1] >= 'a' && strData[i + 1] <= 'f')
						tmpBuffer[i / 2] |= (strData[i + 1] - 'a' + 10);
					else if (strData[i + 1] >= 'A' && strData[i + 1] <= 'F')
						tmpBuffer[i / 2] |= (strData[i + 1] - 'A' + 10);
				}
				HRESULT hr = Toupcam_write_EEPROM(m_hToupCam, uAddr, tmpBuffer, uLength);
				TCHAR strMessage[256];
				_stprintf(strMessage, _T("Write EEPROM, length = %u, result = 0x%08x"), uLength, hr);
				AtlMessageBox(m_hWnd, strMessage);
			}
		}
		return 0;
	}

	LRESULT OnButton3(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		TCHAR strLength[64] = { 0 };
		if (GetDlgItemText(IDC_EDIT2, strLength, _countof(strLength)))
		{
			TCHAR* endptr = NULL;
			unsigned uLength = _tcstoul((LPCTSTR)strLength, &endptr, 16);
			if (uLength)
			{
				unsigned char* tmpWriteBuffer = (unsigned char*)alloca(uLength);
				unsigned char* tmpReadBuffer = (unsigned char*)alloca(uLength);
				HRESULT hr1 = Toupcam_write_EEPROM(m_hToupCam, 0, tmpWriteBuffer, uLength);
				HRESULT hr2 = Toupcam_read_EEPROM(m_hToupCam, 0, tmpReadBuffer, uLength);
				if ((hr1 == uLength) && (hr2 == uLength))
				{
					if (0 == memcmp(tmpWriteBuffer, tmpReadBuffer, uLength))
					{
						AtlMessageBox(m_hWnd, _T("Test OK"));
						return 0;
					}
				}

				AtlMessageBox(m_hWnd, _T("Test Failed"));
			}
		}
		return 0;
	}

	LRESULT OnCancel(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		EndDialog(wID);
		return 0;
	}
};

class CUARTDlg : public CDialogImpl<CUARTDlg>
{
	HToupCam	m_hToupCam;
public:
	enum { IDD = IDD_UART };

	CUARTDlg(HToupCam hToupCam)
		: m_hToupCam(hToupCam)
	{
	}

	BEGIN_MSG_MAP(CUARTDlg)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		COMMAND_ID_HANDLER(IDC_BUTTON1, OnButton1)
		COMMAND_ID_HANDLER(IDC_BUTTON2, OnButton2)
		COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
	END_MSG_MAP()

	LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		CenterWindow(GetParent());
		return TRUE;
	}

	LRESULT OnButton1(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		TCHAR strLength[64] = { 0 };
		if (GetDlgItemText(IDC_EDIT2, strLength, _countof(strLength)))
		{
			TCHAR* endptr = NULL;
			unsigned uLength = _tcstoul(strLength, &endptr, 16);
			if (uLength)
			{
				unsigned char* tmpBuffer = (unsigned char*)alloca(uLength);
				HRESULT hr = Toupcam_read_UART(m_hToupCam, tmpBuffer, uLength);
				if (FAILED(hr))
					AtlMessageBox(m_hWnd, _T("Failed to read UART."));
				else if (0 == hr)
					AtlMessageBox(m_hWnd, _T("Read UART, 0 byte."));
				else if (hr > 0)
				{
					std::wstringstream wstr;
					wstr << _T("UART: length = ") << hr << _T(", data = ");
					for (int i = 0; i < hr; ++i)
						wstr << std::hex << std::setw(2) << std::setfill((TCHAR)'0') << tmpBuffer[i] << _T(" ");
					AtlMessageBox(m_hWnd, wstr.str().c_str());
				}
			}
		}
		return 0;
	}

	LRESULT OnButton2(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		TCHAR strLength[64] = { 0 }, strData[1024] = { 0 };
		if (GetDlgItemText(IDC_EDIT2, strLength, _countof(strLength)) && GetDlgItemText(IDC_EDIT3, strData, _countof(strData)))
		{
			TCHAR* endptr = NULL;
			unsigned uLength = _tcstoul((LPCTSTR)strLength, &endptr, 16);
			if (uLength)
			{
				unsigned char* tmpBuffer = (unsigned char*)alloca(uLength);
				memset(tmpBuffer, 0, uLength);
				for (size_t i = 0; i < _countof(strData); i += 2)
				{
					if ('\0' == strData[0])
						break;
					if (strData[i] >= '0' && strData[i] <= '9')
						tmpBuffer[i / 2] = (strData[i] - '0') << 4;
					else if (strData[i] >= 'a' && strData[i] <= 'f')
						tmpBuffer[i / 2] = (strData[i] - 'a' + 10) << 4;
					else if (strData[i] >= 'A' && strData[i] <= 'F')
						tmpBuffer[i / 2] = (strData[i] - 'A' + 10) << 4;
					if (strData[i + 1] >= '0' && strData[i + 1] <= '9')
						tmpBuffer[i / 2] |= (strData[i + 1] - '0');
					else if (strData[i + 1] >= 'a' && strData[i + 1] <= 'f')
						tmpBuffer[i / 2] |= (strData[i + 1] - 'a' + 10);
					else if (strData[i + 1] >= 'A' && strData[i + 1] <= 'F')
						tmpBuffer[i / 2] |= (strData[i + 1] - 'A' + 10);
				}
				HRESULT hr = Toupcam_write_UART(m_hToupCam, tmpBuffer, uLength);
				TCHAR strMessage[256];
				_stprintf(strMessage, _T("Write UART, length = %u, result = 0x%08x"), uLength, hr);
				AtlMessageBox(m_hWnd, strMessage);
			}
		}
		return 0;
	}

	LRESULT OnCancel(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		EndDialog(wID);
		return 0;
	}
};

class CMainView : public CWindowImpl<CMainView>
{
	CMainFrame*	m_pMainFrame;
	LONG		m_nOldWidth, m_nOldHeight;

public:

	static ATL::CWndClassInfo& GetWndClassInfo()
	{
		static ATL::CWndClassInfo wc =
		{
			{ sizeof(WNDCLASSEX), CS_HREDRAW | CS_VREDRAW, StartWindowProc,
			  0, 0, NULL, NULL, NULL, (HBRUSH)NULL_BRUSH, NULL, NULL, NULL },
			NULL, NULL, IDC_ARROW, TRUE, 0, _T("")
		};
		return wc;
	}

	CMainView(CMainFrame* pMainFrame)
	: m_pMainFrame(pMainFrame), m_nOldWidth(0), m_nOldHeight(0)
	{
	}

	BEGIN_MSG_MAP(CMainView)
		MESSAGE_HANDLER(WM_PAINT, OnWmPaint)
		MESSAGE_HANDLER(WM_ERASEBKGND, OnEraseBkgnd)
	END_MSG_MAP()

	LRESULT OnWmPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnEraseBkgnd(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		return 1;
	}
};

class CWmvRecord
{
	const LONG				m_lFrameWidth, m_lFrameHeight;
	CComPtr<IWMWriter>		m_spIWMWriter;
public:
	CWmvRecord(LONG lFrameWidth, LONG lFrameHeight)
	: m_lFrameWidth(lFrameWidth), m_lFrameHeight(lFrameHeight)
	{
	}

	BOOL StartRecord(const wchar_t* strFilename, DWORD dwBitrate)
	{
		CComPtr<IWMProfileManager> spIWMProfileManager;
		HRESULT hr = WMCreateProfileManager(&spIWMProfileManager);
		if (FAILED(hr))
			return FALSE;

		CComPtr<IWMCodecInfo> spIWMCodecInfo;
		hr = spIWMProfileManager->QueryInterface(__uuidof(IWMCodecInfo), (void**)&spIWMCodecInfo);
		if (FAILED(hr))
			return FALSE;

		DWORD cCodecs = 0;
        hr = spIWMCodecInfo->GetCodecInfoCount(WMMEDIATYPE_Video, &cCodecs);
		if (FAILED(hr))
			return FALSE;

		CComPtr<IWMStreamConfig> spIWMStreamConfig;
        //
        // Search from the last codec because the last codec usually 
        // is the newest codec. 
        //
        for (int i = cCodecs - 1; i >= 0; i--)
        {
            DWORD cFormats;
            hr = spIWMCodecInfo->GetCodecFormatCount(WMMEDIATYPE_Video, i, &cFormats);
			if (FAILED(hr))
				break;

            for (DWORD j = 0; j < cFormats; j++)
			{
                hr = spIWMCodecInfo->GetCodecFormat(WMMEDIATYPE_Video, i, j, &spIWMStreamConfig);
				if (FAILED(hr))
					break;

				hr = ConfigureInput(spIWMStreamConfig, dwBitrate);
				if (SUCCEEDED(hr))
					break;
				spIWMStreamConfig = NULL;
			}
			if (spIWMStreamConfig)
				break;
		}
		if (spIWMStreamConfig == NULL)
			return FALSE;

		CComPtr<IWMProfile> spIWMProfile;
		hr = spIWMProfileManager->CreateEmptyProfile(WMT_VER_8_0, &spIWMProfile);
		if (FAILED(hr))
			return FALSE;

		{
			CComPtr<IWMStreamConfig> spIWMStreamConfig2;
			hr = spIWMProfile->CreateNewStream(WMMEDIATYPE_Video, &spIWMStreamConfig2);
			if (FAILED(hr))
				return FALSE;

			WORD wStreamNum = 1;
			hr = spIWMStreamConfig2->GetStreamNumber(&wStreamNum);
			if (FAILED(hr))
				return FALSE;
			
			hr = spIWMStreamConfig->SetStreamNumber(wStreamNum);
			if (FAILED(hr))
				return FALSE;
		}
		spIWMStreamConfig->SetBitrate(dwBitrate);

		hr = spIWMProfile->AddStream(spIWMStreamConfig);
		if (FAILED(hr))
			return FALSE;

		hr = WMCreateWriter(NULL, &m_spIWMWriter);
		if (FAILED(hr))
			return FALSE;

		hr = m_spIWMWriter->SetProfile(spIWMProfile);
		if (FAILED(hr))
			return FALSE;

		hr = SetInputProps();
		if (FAILED(hr))
			return FALSE;

		hr = m_spIWMWriter->SetOutputFilename(strFilename);
		if (FAILED(hr))
			return FALSE;

		hr = m_spIWMWriter->BeginWriting();
		if (FAILED(hr))
			return FALSE;

		{
			CComPtr<IWMWriterAdvanced> spIWMWriterAdvanced;
			m_spIWMWriter->QueryInterface(__uuidof(IWMWriterAdvanced), (void**)&spIWMWriterAdvanced);
			if (spIWMWriterAdvanced)
				spIWMWriterAdvanced->SetLiveSource(TRUE);
		}

		return TRUE;
	}

	void StopRecord()
	{
		if (m_spIWMWriter)
		{
			m_spIWMWriter->Flush();
			m_spIWMWriter->EndWriting();
			m_spIWMWriter = NULL; 
		}
	}

	BOOL WriteSample(const void* pData)
	{
		CComPtr<INSSBuffer> spINSSBuffer;
		if (SUCCEEDED(m_spIWMWriter->AllocateSample(TDIBWIDTHBYTES(m_lFrameWidth * 24) * m_lFrameHeight, &spINSSBuffer)))
		{
			BYTE* pBuffer = NULL;
			if (SUCCEEDED(spINSSBuffer->GetBuffer(&pBuffer)))
			{
				memcpy(pBuffer, pData, TDIBWIDTHBYTES(m_lFrameWidth * 24) * m_lFrameHeight);
				spINSSBuffer->SetLength(TDIBWIDTHBYTES(m_lFrameWidth * 24) * m_lFrameHeight);
				QWORD cnsSampleTime = GetTickCount();
				m_spIWMWriter->WriteSample(0, cnsSampleTime * 1000 * 10, 0, spINSSBuffer);
				return TRUE;
			}
		}

		return FALSE;
	}

private:
	HRESULT SetInputProps()
	{
		DWORD dwForamts = 0;
		HRESULT hr = m_spIWMWriter->GetInputFormatCount(0, &dwForamts);
		if (FAILED(hr))
			return hr;

		for (DWORD i = 0; i < dwForamts; ++i)
		{
			CComPtr<IWMInputMediaProps> spIWMInputMediaProps;
			hr = m_spIWMWriter->GetInputFormat(0, i, &spIWMInputMediaProps);
			if (FAILED(hr))
				return hr;

			DWORD cbSize = 0;
			hr = spIWMInputMediaProps->GetMediaType(NULL, &cbSize);
			if (FAILED(hr))
				return hr;

			WM_MEDIA_TYPE* pMediaType = (WM_MEDIA_TYPE*)alloca(cbSize);
			hr = spIWMInputMediaProps->GetMediaType(pMediaType, &cbSize);
			if (FAILED(hr))
				return hr;

			if (pMediaType->subtype == WMMEDIASUBTYPE_RGB24)
			{
				hr = spIWMInputMediaProps->SetMediaType(pMediaType);
				if (FAILED(hr))
					return hr;

				return m_spIWMWriter->SetInputProps(0, spIWMInputMediaProps);
			}
		}

		return E_FAIL;
	}

	HRESULT ConfigureInput(CComPtr<IWMStreamConfig>& spIWMStreamConfig, DWORD dwBitRate)
	{
		CComPtr<IWMVideoMediaProps> spIWMVideoMediaProps;
		HRESULT hr = spIWMStreamConfig->QueryInterface(__uuidof(IWMVideoMediaProps), (void**)&spIWMVideoMediaProps);
		if (FAILED(hr))
			return hr;

		DWORD cbMT = 0;
		hr = spIWMVideoMediaProps->GetMediaType(NULL, &cbMT);
		if (FAILED(hr))
			return hr;

		// Allocate memory for the media type structure.
		WM_MEDIA_TYPE* pType = (WM_MEDIA_TYPE*)alloca(cbMT);
		// Get the media type structure.
		hr = spIWMVideoMediaProps->GetMediaType(pType, &cbMT);
		if (FAILED(hr) || (pType->formattype != WMFORMAT_VideoInfo) || (NULL == pType->pbFormat))
			return E_FAIL;
		
		bool bFound = false;
		// First set pointers to the video structures.
		WMVIDEOINFOHEADER* pVidHdr = (WMVIDEOINFOHEADER*)pType->pbFormat;
		{
			const DWORD FourCC[] =
			{
				MAKEFOURCC('W', 'M', 'V', '3'),
				MAKEFOURCC('W', 'M', 'V', '2'),
				MAKEFOURCC('W', 'M', 'V', '1')
			};
			for (size_t i = 0; i < _countof(FourCC); ++i)
			{
				if (FourCC[i] == pVidHdr->bmiHeader.biCompression)
				{
					bFound = true;
					break;
				}
			}
		}
		if (!bFound)
			return E_FAIL;

		pVidHdr->dwBitRate = dwBitRate;
		pVidHdr->rcSource.right = m_lFrameWidth;
		pVidHdr->rcSource.bottom = m_lFrameHeight;
		pVidHdr->rcTarget.right = m_lFrameWidth;
		pVidHdr->rcTarget.bottom = m_lFrameHeight;

		BITMAPINFOHEADER* pbmi = &(pVidHdr->bmiHeader);
		pbmi->biWidth  = m_lFrameWidth;
		pbmi->biHeight = m_lFrameHeight;
    
		// Stride = (width * bytes/pixel), rounded to the next DWORD boundary.
		LONG lStride = (m_lFrameWidth * (pbmi->biBitCount / 8) + 3) & ~3;

		// Image size = stride * height. 
		pbmi->biSizeImage = m_lFrameHeight * lStride;

		// Apply the adjusted type to the video input. 
		hr = spIWMVideoMediaProps->SetMediaType(pType);
		if (FAILED(hr))
			return hr;

		/* you can change this quality */
		spIWMVideoMediaProps->SetQuality(100);
		return hr;
	}
};

class CMainFrame : public CFrameWindowImpl<CMainFrame>, public CUpdateUI<CMainFrame>
{
	HToupCam		m_Htoupcam;
	CMainView		m_view;
	ToupcamInstV2	m_ti[TOUPCAM_MAX];
	unsigned		m_nIndex;
	BOOL			m_bPaused, m_bSnaping;
	unsigned		m_nFrameCount;
	DWORD			m_dwStartTick, m_dwLastTick;

	wchar_t				m_szFilePath[MAX_PATH];

	CWmvRecord*			m_pWmvRecord;
	BYTE*				m_pData;
	BITMAPINFOHEADER	m_header;

	bool		m_bTriggerMode;
	unsigned	m_nTriggerNumber;
public:
	DECLARE_FRAME_WND_CLASS(NULL, IDR_MAIN)

	BEGIN_MSG_MAP_EX(CMainFrame)
		MSG_WM_CREATE(OnCreate)
		MESSAGE_HANDLER(WM_DESTROY, OnWmDestroy)
		MESSAGE_HANDLER(MSG_CAMEVENT, OnMsgCamEvent)
		COMMAND_RANGE_HANDLER_EX(ID_DEVICE_DEVICE0, ID_DEVICE_DEVICEF, OnOpenDevice)
		COMMAND_RANGE_HANDLER_EX(ID_PREVIEW_RESOLUTION0, ID_PREVIEW_RESOLUTION4, OnPreviewResolution)
		COMMAND_RANGE_HANDLER_EX(ID_SNAP_RESOLUTION0, ID_SNAP_RESOLUTION4, OnSnapResolution)
		COMMAND_ID_HANDLER_EX(ID_CONFIG_WHITEBALANCE, OnWhiteBalance)
		COMMAND_ID_HANDLER_EX(ID_CONFIG_AUTOEXPOSURE, OnAutoExposure)
		COMMAND_ID_HANDLER_EX(ID_CONFIG_VERTICALFLIP, OnVerticalFlip)
		COMMAND_ID_HANDLER_EX(ID_CONFIG_HORIZONTALFLIP, OnHorizontalFlip)
		COMMAND_ID_HANDLER_EX(ID_ACTION_PAUSE, OnPause)
		COMMAND_ID_HANDLER_EX(ID_CONFIG_EXPOSURETIME, OnExposureTime)
		COMMAND_ID_HANDLER_EX(ID_ACTION_STARTRECORD, OnStartRecord)
		COMMAND_ID_HANDLER_EX(ID_ACTION_STOPRECORD, OnStopRecord)
		COMMAND_ID_HANDLER_EX(ID_ACTION_LED, OnLed)
		COMMAND_ID_HANDLER_EX(ID_BITDEPTH, OnBitdepth)
		COMMAND_ID_HANDLER_EX(ID_ACTION_EEPROM, OnEEPROM)
		COMMAND_ID_HANDLER_EX(ID_ACTION_UART, OnUART)
		COMMAND_ID_HANDLER_EX(ID_ACTION_FWVER, OnFwVer)
		COMMAND_ID_HANDLER_EX(ID_ACTION_HWVER, OnHwVer)
		COMMAND_ID_HANDLER_EX(ID_ACTION_FPGAVER, OnFpgaVer)
		COMMAND_ID_HANDLER_EX(ID_ACTION_PRODUCTIONDATE, OnProductionDate)
		COMMAND_ID_HANDLER_EX(ID_ACTION_SN, OnSn)
		COMMAND_ID_HANDLER_EX(ID_ACTION_ROI, OnRoi)
		COMMAND_ID_HANDLER_EX(ID_CONFIG_PROP, OnProp)
		COMMAND_ID_HANDLER_EX(ID_TRIGGER_MODE, OnTriggerMode)
		COMMAND_ID_HANDLER_EX(ID_TRIGGER_TRIGGER, OnTriggerTrigger)
		COMMAND_ID_HANDLER_EX(ID_TRIGGER_NUMBER, OnTriggerNumber)
		CHAIN_MSG_MAP(CUpdateUI<CMainFrame>)
		CHAIN_MSG_MAP(CFrameWindowImpl<CMainFrame>)
	END_MSG_MAP()

	BEGIN_UPDATE_UI_MAP(CMainFrame)
		UPDATE_ELEMENT(ID_CONFIG_WHITEBALANCE, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_CONFIG_AUTOEXPOSURE, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_CONFIG_VERTICALFLIP, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_CONFIG_HORIZONTALFLIP, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_ACTION_STARTRECORD, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_ACTION_STOPRECORD, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_ACTION_PAUSE, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_ACTION_LED, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_BITDEPTH, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_ACTION_EEPROM, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_ACTION_UART, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_ACTION_FWVER, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_ACTION_HWVER, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_ACTION_FPGAVER, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_ACTION_PRODUCTIONDATE, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_ACTION_SN, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_ACTION_ROI, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_CONFIG_EXPOSURETIME, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_PREVIEW_RESOLUTION0, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_PREVIEW_RESOLUTION1, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_PREVIEW_RESOLUTION2, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_PREVIEW_RESOLUTION3, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_PREVIEW_RESOLUTION4, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_SNAP_RESOLUTION0, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_SNAP_RESOLUTION1, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_SNAP_RESOLUTION2, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_SNAP_RESOLUTION3, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_SNAP_RESOLUTION4, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_CONFIG_PROP, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_TRIGGER_MODE, UPDUI_MENUPOPUP)
		UPDATE_ELEMENT(ID_TRIGGER_TRIGGER, UPDUI_MENUPOPUP)
	END_UPDATE_UI_MAP()

	LRESULT OnMsgCamEvent(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		switch (wParam)
		{
		case TOUPCAM_EVENT_ERROR:
		case TOUPCAM_EVENT_TIMEOUT:
			OnEventUsbError();
			break;
		case TOUPCAM_EVENT_DISCONNECTED:
			OnEventUsbDisconnected();
			break;
		case TOUPCAM_EVENT_EXPOSURE:
			OnEventExpo();
			break;
		case TOUPCAM_EVENT_TEMPTINT:
			OnEventTemptint();
			break;
		case TOUPCAM_EVENT_IMAGE:
			OnEventImage();
			break;
		case TOUPCAM_EVENT_STILLIMAGE:
			OnEventSnap();
			break;
		}
		return 0;
	}

	CMainFrame()
	: m_Htoupcam(NULL), m_nIndex(0), m_bPaused(FALSE), m_bSnaping(FALSE), m_nFrameCount(0), m_dwStartTick(0), m_dwLastTick(0), m_pWmvRecord(NULL), m_pData(NULL), m_view(this)
	{
		m_bTriggerMode = false;
		m_nTriggerNumber = 1;

		memset(m_ti, 0, sizeof(m_ti));
		memset(m_szFilePath, 0, sizeof(m_szFilePath));
		
		memset(&m_header, 0, sizeof(m_header));
		m_header.biSize = sizeof(BITMAPINFOHEADER);
		m_header.biPlanes = 1;
		m_header.biBitCount = 24;
	}

	int OnCreate(LPCREATESTRUCT /*lpCreateStruct*/)
	{
		CMenuHandle menu = GetMenu();
		CMenuHandle submenu = menu.GetSubMenu(0);
		while (submenu.GetMenuItemCount() > 0)
			submenu.RemoveMenu(submenu.GetMenuItemCount() - 1, MF_BYPOSITION);

		unsigned cnt = Toupcam_EnumV2(m_ti);
		if (0 == cnt)
			submenu.AppendMenu(MF_GRAYED | MF_STRING, ID_DEVICE_DEVICE0, L"No Device");
		else
		{
			for (unsigned i = 0; i < cnt; ++i)
				submenu.AppendMenu(MF_STRING, ID_DEVICE_DEVICE0 + i, m_ti[i].displayname);
		}

		CreateSimpleStatusBar();
		{
			int iWidth[] = { 150, 400, 600, -1 };
			CStatusBarCtrl statusbar(m_hWndStatusBar);
			statusbar.SetParts(_countof(iWidth), iWidth);
		}

		m_hWndClient = m_view.Create(m_hWnd, rcDefault, NULL, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN, WS_EX_CLIENTEDGE);
		
		OnDeviceChanged();
		return 0;
	}

	void OnWhiteBalance(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		if (m_Htoupcam)
			Toupcam_AwbOnePush(m_Htoupcam, NULL, NULL);
	}

	void OnAutoExposure(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		if (m_Htoupcam)
		{
			BOOL bAutoExposure = FALSE;
			if (SUCCEEDED(Toupcam_get_AutoExpoEnable(m_Htoupcam, &bAutoExposure)))
			{
				bAutoExposure = !bAutoExposure;
				Toupcam_put_AutoExpoEnable(m_Htoupcam, bAutoExposure);
				UISetCheck(ID_CONFIG_AUTOEXPOSURE, bAutoExposure ? 1 : 0);
				UIEnable(ID_CONFIG_EXPOSURETIME, !bAutoExposure);
			}
		}
	}

	void OnVerticalFlip(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		if (m_Htoupcam)
		{
			BOOL b = FALSE;
			if (SUCCEEDED(Toupcam_get_VFlip(m_Htoupcam, &b)))
			{
				b = !b;
				Toupcam_put_VFlip(m_Htoupcam, b);
				UISetCheck(ID_CONFIG_VERTICALFLIP, b ? 1 : 0);
			}
		}
	}

	void OnHorizontalFlip(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		if (m_Htoupcam)
		{
			BOOL b = FALSE;
			if (SUCCEEDED(Toupcam_get_HFlip(m_Htoupcam, &b)))
			{
				b = !b;
				Toupcam_put_HFlip(m_Htoupcam, b);
				UISetCheck(ID_CONFIG_HORIZONTALFLIP, b ? 1 : 0);
			}
		}
	}

	void OnPause(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		if (m_Htoupcam)
		{
			m_bPaused = !m_bPaused;
			Toupcam_Pause(m_Htoupcam, m_bPaused);
			
			UISetCheck(ID_ACTION_PAUSE, m_bPaused ? 1 : 0);
			UIEnable(ID_ACTION_STARTRECORD, !m_bPaused);
		}
	}

	void OnExposureTime(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		if (m_Htoupcam)
		{
			CExposureTimeDlg dlg(m_Htoupcam);
			if (IDOK == dlg.DoModal())
				UpdateExposureTimeText();
		}
	}

	void OnLed(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		if (m_Htoupcam)
		{
			CLedDlg dlg(m_Htoupcam);
			dlg.DoModal();
		}
	}

	void OnBitdepth(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		if (m_Htoupcam)
		{
			CBitdepthDlg dlg(m_Htoupcam);
			dlg.DoModal();
		}
	}

	void OnEEPROM(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		if (m_Htoupcam)
		{
			CEEPROMDlg dlg(m_Htoupcam);
			dlg.DoModal();
		}
	}

	void OnUART(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		if (m_Htoupcam)
		{
			CUARTDlg dlg(m_Htoupcam);
			dlg.DoModal();
		}
	}

	void OnRoi(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		if (m_Htoupcam)
		{
			CRoiDlg dlg;
			Toupcam_get_Roi(m_Htoupcam, &dlg.xOffset_, &dlg.yOffset_, &dlg.xWidth_, &dlg.yHeight_);
			if (IDOK == dlg.DoModal())
			{
				if (SUCCEEDED(Toupcam_put_Roi(m_Htoupcam, dlg.xOffset_, dlg.yOffset_, dlg.xWidth_, dlg.yHeight_)))
				{
					Toupcam_get_Roi(m_Htoupcam, NULL, NULL, (unsigned*)&m_header.biWidth, (unsigned*)&m_header.biHeight);
					m_header.biSizeImage = TDIBWIDTHBYTES(m_header.biWidth * m_header.biBitCount) * m_header.biHeight;
					UpdateResolutionText();
				}
			}
		}
	}

	void OnFwVer(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		char ver[16] = { 0 };
		if (SUCCEEDED(Toupcam_get_FwVersion(m_Htoupcam, ver)))
		{
			CA2T a2t(ver);
			AtlMessageBox(m_hWnd, a2t.m_psz, L"FwVer");
		}
	}

	void OnHwVer(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		char ver[16] = { 0 };
		if (SUCCEEDED(Toupcam_get_HwVersion(m_Htoupcam, ver)))
		{
			CA2T a2t(ver);
			AtlMessageBox(m_hWnd, a2t.m_psz, L"HwVer");
		}
	}

	void OnFpgaVer(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		char ver[16] = { 0 };
		if (SUCCEEDED(Toupcam_get_FpgaVersion(m_Htoupcam, ver)))
		{
			CA2T a2t(ver);
			AtlMessageBox(m_hWnd, a2t.m_psz, L"FPGAVer");
		}
	}

	void OnProductionDate(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		char pdate[10] = { 0 };
		if (SUCCEEDED(Toupcam_get_ProductionDate(m_Htoupcam, pdate)))
		{
			CA2T a2t(pdate);
			AtlMessageBox(m_hWnd, a2t.m_psz, L"ProductionDate");
		}
	}

	void OnSn(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		char sn[32] = { 0 };
		if (SUCCEEDED(Toupcam_get_SerialNumber(m_Htoupcam, sn)))
		{
			CA2T a2t(sn);
			AtlMessageBox(m_hWnd, a2t.m_psz, L"Serial Number");
		}
	}

	void OnProp(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
#ifdef _USE_TOUPCAMPROP_
		if (m_Htoupcam)
			toupcamprop_propertysheet(m_Htoupcam, m_hWnd);
#else
		AtlMessageBox(m_hWnd, _T("If you want to use toupcamprop.dll, please define _USE_TOUPCAMPROP_ preprocessor macro in the VC project."));
#endif
	}

	void OnTriggerMode(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		m_bTriggerMode = !m_bTriggerMode;
		UISetCheck(ID_TRIGGER_MODE, m_bTriggerMode);
		UIEnable(ID_ACTION_STOPRECORD, (m_Htoupcam && m_bTriggerMode) ? TRUE : FALSE);
	}

	void OnTriggerNumber(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		CTriggerNumberDlg dlg;
		dlg.number_ = m_nTriggerNumber;
		if (IDOK == dlg.DoModal())
			m_nTriggerNumber = dlg.number_;
	}

	void OnTriggerTrigger(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		if (m_Htoupcam)
		{
			HRESULT hr = Toupcam_Trigger(m_Htoupcam, m_nTriggerNumber);
			if (E_INVALIDARG == hr)
			{
				if (m_nTriggerNumber > 1)
					AtlMessageBox(m_hWnd, L"TOUPCAM_FLAG_TRIGGER_SINGLE: only number = 1 supported");
			}
		}
	}

	void OnPreviewResolution(UINT /*uNotifyCode*/, int nID, HWND /*wndCtl*/)
	{
		if (NULL == m_Htoupcam)
			return;

		unsigned eSize = 0;
		if (SUCCEEDED(Toupcam_get_eSize(m_Htoupcam, &eSize)))
		{
			if (eSize != nID - ID_PREVIEW_RESOLUTION0)
			{
				if (SUCCEEDED(Toupcam_Stop(m_Htoupcam)))
				{
					OnStopRecord(0, 0, NULL);

					m_bPaused = m_bSnaping = FALSE;
					UISetCheck(ID_ACTION_PAUSE, FALSE);
					m_nFrameCount = 0;
					m_dwStartTick = m_dwLastTick = 0;

					Toupcam_put_eSize(m_Htoupcam, nID - ID_PREVIEW_RESOLUTION0);
					for (unsigned i = 0; i < m_ti[m_nIndex].model->preview; ++i)
						UISetCheck(ID_PREVIEW_RESOLUTION0 + i, (nID - ID_PREVIEW_RESOLUTION0 == i) ? 1 : 0);
					UpdateSnapMenu();
					if (SUCCEEDED(Toupcam_get_Size(m_Htoupcam, (int*)&m_header.biWidth, (int*)&m_header.biHeight)))
					{
						UpdateResolutionText();
						UpdateFrameText();
						UpdateExposureTimeText();

						m_header.biSizeImage = TDIBWIDTHBYTES(m_header.biWidth * m_header.biBitCount) * m_header.biHeight;
						if (m_pData)
						{
							free(m_pData);
							m_pData = NULL;
						}
						m_pData = (BYTE*)malloc(m_header.biSizeImage);
						if (SUCCEEDED(Toupcam_StartPullModeWithWndMsg(m_Htoupcam, m_hWnd, MSG_CAMEVENT)))
						{
							UIEnable(ID_ACTION_PAUSE, TRUE);
							UIEnable(ID_ACTION_STARTRECORD, TRUE);
						}
					}
				}
			}
		}
	}

	void OnSnapResolution(UINT /*uNotifyCode*/, int nID, HWND /*wndCtl*/)
	{
		if (NULL == m_Htoupcam)
			return;

		CFileDialog dlg(FALSE, L"jpg");
		if (IDOK == dlg.DoModal())
		{
			wcscpy(m_szFilePath, dlg.m_szFileName);
			if (SUCCEEDED(Toupcam_Snap(m_Htoupcam, nID - ID_SNAP_RESOLUTION0)))
			{
				m_bSnaping = TRUE;
				UpdateSnapMenu();
			}
		}
	}

	void OnOpenDevice(UINT /*uNotifyCode*/, int nID, HWND /*wndCtl*/)
	{
		CloseDevice();

		m_bPaused = m_bSnaping = FALSE;
		UISetCheck(ID_ACTION_PAUSE, FALSE);
		m_nFrameCount = 0;
		m_dwStartTick = m_dwLastTick = 0;
		m_nIndex = nID - ID_DEVICE_DEVICE0;
		m_Htoupcam = Toupcam_Open(m_ti[m_nIndex].id);
		if (m_Htoupcam)
		{
			OnDeviceChanged();
			UpdateFrameText();

			if (SUCCEEDED(Toupcam_get_Size(m_Htoupcam, (int*)&m_header.biWidth, (int*)&m_header.biHeight)))
			{
				m_header.biSizeImage = TDIBWIDTHBYTES(m_header.biWidth * m_header.biBitCount) * m_header.biHeight;
				m_pData = (BYTE*)malloc(m_header.biSizeImage);
				unsigned eSize = 0;
				if (SUCCEEDED(Toupcam_get_eSize(m_Htoupcam, &eSize)))
				{
					for (unsigned i = 0; i < m_ti[m_nIndex].model->preview; ++i)
						UISetCheck(ID_PREVIEW_RESOLUTION0 + i, (eSize == i) ? 1 : 0);
				}
				if (m_bTriggerMode)
					Toupcam_put_Option(m_Htoupcam, TOUPCAM_OPTION_TRIGGER, 1);
				if (SUCCEEDED(Toupcam_StartPullModeWithWndMsg(m_Htoupcam, m_hWnd, MSG_CAMEVENT)))
				{
					UIEnable(ID_ACTION_PAUSE, TRUE);
					UIEnable(ID_ACTION_STARTRECORD, TRUE);
				}
			}
		}
	}

	void OnStartRecord(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		CFileDialog dlg(FALSE, L"wmv");
		if (IDOK == dlg.DoModal())
		{
			StopRecord();

			DWORD dwBitrate = 4 * 1024 * 1024; /* bitrate, you can change this setting */
			CWmvRecord* pWmvRecord = new CWmvRecord(m_header.biWidth, m_header.biHeight);
			if (pWmvRecord->StartRecord(dlg.m_szFileName, dwBitrate))
			{
				m_pWmvRecord = pWmvRecord;
				UIEnable(ID_ACTION_STARTRECORD, FALSE);
				UIEnable(ID_ACTION_STOPRECORD, TRUE);
			}
			else
			{
				delete pWmvRecord;
			}
		}
	}

	void OnStopRecord(UINT /*uNotifyCode*/, int /*nID*/, HWND /*wndCtl*/)
	{
		StopRecord();

		UIEnable(ID_ACTION_STARTRECORD, m_Htoupcam ? TRUE : FALSE);
		UIEnable(ID_ACTION_STOPRECORD, FALSE);
	}

	void OnEventImage()
	{
		unsigned nWidth = 0, nHeight = 0;
		HRESULT hr = Toupcam_PullImage(m_Htoupcam, m_pData, m_header.biBitCount, &nWidth, &nHeight);
		if (FAILED(hr))
			return;
		if ((nWidth != m_header.biWidth) || (nHeight != m_header.biHeight))
			return;

		++m_nFrameCount;
		if (0 == m_dwStartTick)
		{
			m_dwLastTick = m_dwStartTick = GetTickCount();
		}
		else
		{
			m_dwLastTick = GetTickCount();
		}
		m_view.Invalidate();

		UpdateFrameText();
		if (m_pWmvRecord)
			m_pWmvRecord->WriteSample(m_pData);
	}

	void OnEventSnap()
	{
		BITMAPINFOHEADER header = { 0 };
		header.biSize = sizeof(header);
		header.biPlanes = 1;
		header.biBitCount = 24;
		HRESULT hr = Toupcam_PullStillImage(m_Htoupcam, NULL, 24, (unsigned*)&header.biWidth, (unsigned*)&header.biHeight); //first, peek the width and height
		if (SUCCEEDED(hr))
		{
			header.biSizeImage = TDIBWIDTHBYTES(header.biWidth * header.biBitCount) * header.biHeight;
			void* pSnapData = malloc(header.biSizeImage);
			if (pSnapData)
			{
				hr = Toupcam_PullStillImage(m_Htoupcam, pSnapData, 24, NULL, NULL);
				if (SUCCEEDED(hr))
				{
					if (PathMatchSpec(m_szFilePath, L"*.bmp"))
						SaveImageBmp(m_szFilePath, pSnapData, &header);
					else
						SaveImageByWIC(m_szFilePath, pSnapData, &header);
				}

				free(pSnapData);
			}
		}

		m_bSnaping = FALSE;
		UpdateSnapMenu();
	}

	LRESULT OnWmDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		CloseDevice();

		CFrameWindowImpl<CMainFrame>::OnDestroy(uMsg, wParam, lParam, bHandled);
		return 0;
	}

	void OnEventUsbError()
	{
		CloseDevice();
		AtlMessageBox(m_hWnd, _T("Error"));
	}

	void OnEventUsbDisconnected()
	{
		CloseDevice();
		AtlMessageBox(m_hWnd, _T("The camera is disconnected, maybe has been pulled out."));
	}

	void OnEventTemptint()
	{
		CStatusBarCtrl statusbar(m_hWndStatusBar);
		wchar_t res[128];
		int nTemp = TOUPCAM_TEMP_DEF, nTint = TOUPCAM_TINT_DEF;
		Toupcam_get_TempTint(m_Htoupcam, &nTemp, &nTint);
		swprintf(res, L"Temp = %d, Tint = %d", nTemp, nTint);
		statusbar.SetText(2, res);
	}

	void OnEventExpo()
	{
		CStatusBarCtrl statusbar(m_hWndStatusBar);
		wchar_t res[128];
		unsigned nTime = 0;
		unsigned short AGain = 0;
		if (SUCCEEDED(Toupcam_get_ExpoTime(m_Htoupcam, &nTime)) && SUCCEEDED(Toupcam_get_ExpoAGain(m_Htoupcam, &AGain)))
		{
			swprintf(res, L"ExposureTime = %u, AGain = %hu", nTime, AGain);
			statusbar.SetText(1, res);
		}
	}

	BOOL GetData(BITMAPINFOHEADER** pHeader, BYTE** pData)
	{
		if (m_pData)
		{
			*pData = m_pData;
			*pHeader = &m_header;
			return TRUE;
		}

		return FALSE;
	}

private:
	void CloseDevice()
	{
		OnStopRecord(0, 0, NULL);

		if (m_Htoupcam)
		{
			Toupcam_Close(m_Htoupcam);
			m_Htoupcam = NULL;

			if (m_pData)
			{
				free(m_pData);
				m_pData = NULL;
			}
		}
		OnDeviceChanged();
	}

	void OnDeviceChanged()
	{
		CMenuHandle menu = GetMenu();
		CMenuHandle submenu = menu.GetSubMenu(1);
		CMenuHandle previewsubmenu = submenu.GetSubMenu(0);
		CMenuHandle snapsubmenu = submenu.GetSubMenu(1);
		while (previewsubmenu.GetMenuItemCount() > 0)
			previewsubmenu.RemoveMenu(previewsubmenu.GetMenuItemCount() - 1, MF_BYPOSITION);
		while (snapsubmenu.GetMenuItemCount() > 0)
			snapsubmenu.RemoveMenu(snapsubmenu.GetMenuItemCount() - 1, MF_BYPOSITION);

		CStatusBarCtrl statusbar(m_hWndStatusBar);

		if (NULL == m_Htoupcam)
		{
			previewsubmenu.AppendMenu(MF_STRING | MF_GRAYED, ID_PREVIEW_RESOLUTION0, L"Empty");
			snapsubmenu.AppendMenu(MF_STRING | MF_GRAYED, ID_SNAP_RESOLUTION0, L"Empty");

			statusbar.SetText(0, L"");
			statusbar.SetText(1, L"");
			statusbar.SetText(2, L"");
			statusbar.SetText(3, L"");

			UISetCheck(ID_CONFIG_AUTOEXPOSURE, 0);
			UIEnable(ID_CONFIG_EXPOSURETIME, FALSE);
			UIEnable(ID_PREVIEW_RESOLUTION0, FALSE);
			UIEnable(ID_SNAP_RESOLUTION0, FALSE);
			UIEnable(ID_ACTION_LED, FALSE);
			UIEnable(ID_BITDEPTH, FALSE);
			UIEnable(ID_ACTION_EEPROM, FALSE);
			UIEnable(ID_ACTION_UART, FALSE);
			UIEnable(ID_ACTION_FWVER, FALSE);
			UIEnable(ID_ACTION_HWVER, FALSE);
			UIEnable(ID_ACTION_FPGAVER, FALSE);
			UIEnable(ID_ACTION_PRODUCTIONDATE, FALSE);
			UIEnable(ID_ACTION_SN, FALSE);
			UIEnable(ID_ACTION_ROI, FALSE);
			UIEnable(ID_CONFIG_PROP, FALSE);
		}
		else
		{
			unsigned eSize = 0;
			Toupcam_get_eSize(m_Htoupcam, &eSize);

			wchar_t res[128];
			for (unsigned i = 0; i < m_ti[m_nIndex].model->preview; ++i)
			{
				swprintf(res, L"%u * %u", m_ti[m_nIndex].model->res[i].width, m_ti[m_nIndex].model->res[i].height);
				previewsubmenu.AppendMenu(MF_STRING, ID_PREVIEW_RESOLUTION0 + i, res);
				snapsubmenu.AppendMenu(MF_STRING, ID_SNAP_RESOLUTION0 + i, res);

				UIEnable(ID_PREVIEW_RESOLUTION0 + i, TRUE);
			}
			UpdateSnapMenu();

			UpdateResolutionText();
			UpdateExposureTimeText();

			int nTemp = TOUPCAM_TEMP_DEF, nTint = TOUPCAM_TINT_DEF;
			if (SUCCEEDED(Toupcam_get_TempTint(m_Htoupcam, &nTemp, &nTint)))
			{
				swprintf(res, L"Temp = %d, Tint = %d", nTemp, nTint);
				statusbar.SetText(2, res);
			}

			BOOL bAutoExposure = TRUE;
			if (SUCCEEDED(Toupcam_get_AutoExpoEnable(m_Htoupcam, &bAutoExposure)))
			{
				UISetCheck(ID_CONFIG_AUTOEXPOSURE, bAutoExposure ? 1 : 0);
				UIEnable(ID_CONFIG_EXPOSURETIME, !bAutoExposure);
			}
		}

		UIEnable(ID_ACTION_PAUSE, FALSE);
		UIEnable(ID_ACTION_STARTRECORD, FALSE);
		UIEnable(ID_ACTION_STOPRECORD, FALSE);
		UIEnable(ID_CONFIG_AUTOEXPOSURE, m_Htoupcam ? TRUE : FALSE);
		UIEnable(ID_CONFIG_HORIZONTALFLIP, m_Htoupcam ? TRUE : FALSE);
		UIEnable(ID_CONFIG_VERTICALFLIP, m_Htoupcam ? TRUE : FALSE);
		UIEnable(ID_CONFIG_WHITEBALANCE, m_Htoupcam ? TRUE : FALSE);
		UIEnable(ID_ACTION_LED, m_Htoupcam ? TRUE : FALSE);
		UIEnable(ID_BITDEPTH, m_Htoupcam ? TRUE : FALSE);
		UIEnable(ID_ACTION_EEPROM, m_Htoupcam ? TRUE : FALSE);
		UIEnable(ID_ACTION_UART, m_Htoupcam ? TRUE : FALSE);
		UIEnable(ID_ACTION_FWVER, m_Htoupcam ? TRUE : FALSE);
		UIEnable(ID_ACTION_HWVER, m_Htoupcam ? TRUE : FALSE);
		UIEnable(ID_ACTION_FPGAVER, m_Htoupcam ? TRUE : FALSE);
		UIEnable(ID_ACTION_PRODUCTIONDATE, m_Htoupcam ? TRUE : FALSE);
		UIEnable(ID_ACTION_SN, m_Htoupcam ? TRUE : FALSE);
		UIEnable(ID_ACTION_ROI, m_Htoupcam ? TRUE : FALSE);
		UIEnable(ID_CONFIG_PROP, m_Htoupcam ? TRUE : FALSE);
		UISetCheck(ID_ACTION_PAUSE, 0);
		UISetCheck(ID_CONFIG_HORIZONTALFLIP, 0);
		UISetCheck(ID_CONFIG_VERTICALFLIP, 0);
		UIEnable(ID_ACTION_STOPRECORD, (m_Htoupcam && m_bTriggerMode) ? TRUE : FALSE);
	}

	void UpdateSnapMenu()
	{
		if (m_bSnaping)
		{
			for (unsigned i = 0; i < m_ti[m_nIndex].model->preview; ++i)
				UIEnable(ID_SNAP_RESOLUTION0 + i, FALSE);
			return;
		}

		unsigned eSize = 0;
		if (SUCCEEDED(Toupcam_get_eSize(m_Htoupcam, &eSize)))
		{
			for (unsigned i = 0; i < m_ti[m_nIndex].model->preview; ++i)
			{
				if (m_ti[m_nIndex].model->still == m_ti[m_nIndex].model->preview) /* still capture full supported */
				{
					UIEnable(ID_SNAP_RESOLUTION0 + i, TRUE);
				}
				else if (0 == m_ti[m_nIndex].model->still) /* still capture not supported */
				{
					UIEnable(ID_SNAP_RESOLUTION0 + i, (eSize == i) ? TRUE : FALSE);
				}
				else if (m_ti[m_nIndex].model->still < m_ti[m_nIndex].model->preview)
				{
					if ((eSize == i) || (i < m_ti[m_nIndex].model->still))
						UIEnable(ID_SNAP_RESOLUTION0 + i, TRUE);
					else
						UIEnable(ID_SNAP_RESOLUTION0 + i, FALSE);
				}
			}
		}
	}

	void UpdateResolutionText()
	{
		CStatusBarCtrl statusbar(m_hWndStatusBar);
		wchar_t res[128];
		unsigned xOffset = 0, yOffset = 0, nWidth = 0, nHeight = 0;
		if (SUCCEEDED(Toupcam_get_Roi(m_Htoupcam, &xOffset, &yOffset, &nWidth, &nHeight)))
		{
			swprintf(res, L"%u, %u, %u * %u", xOffset, yOffset, nWidth, nHeight);
			statusbar.SetText(0, res);
		}
	}

	void UpdateFrameText()
	{
		CStatusBarCtrl statusbar(m_hWndStatusBar);
		wchar_t str[256];
		if (m_dwLastTick != m_dwStartTick)
			swprintf(str, L"%u, %.2f", m_nFrameCount, m_nFrameCount / ((m_dwLastTick - m_dwStartTick) / 1000.0));
		else
			swprintf(str, L"%u", m_nFrameCount);
		statusbar.SetText(3, str);
	}

	void UpdateExposureTimeText()
	{
		CStatusBarCtrl statusbar(m_hWndStatusBar);
		wchar_t res[128];
		unsigned nTime = 0;
		unsigned short AGain = 0;
		if (SUCCEEDED(Toupcam_get_ExpoTime(m_Htoupcam, &nTime)) && SUCCEEDED(Toupcam_get_ExpoAGain(m_Htoupcam, &AGain)))
		{
			swprintf(res, L"ExposureTime = %u, AGain = %hu", nTime, AGain);
			statusbar.SetText(1, res);
		}
	}

	/* this is called in the UI thread */
	void StopRecord()
	{
		if (m_pWmvRecord)
		{
			m_pWmvRecord->StopRecord();

			delete m_pWmvRecord;
			m_pWmvRecord = NULL;
		}
	}
};

LRESULT CMainView::OnWmPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	CPaintDC dc(m_hWnd);

	RECT rc;
	GetClientRect(&rc);
	BITMAPINFOHEADER* pHeader = NULL;
	BYTE* pData = NULL;
	if (m_pMainFrame->GetData(&pHeader, &pData))
	{
		if ((m_nOldWidth != pHeader->biWidth) || (m_nOldHeight != pHeader->biHeight))
		{
			m_nOldWidth = pHeader->biWidth;
			m_nOldHeight = pHeader->biHeight;
			dc.FillRect(&rc, (HBRUSH)WHITE_BRUSH);
		}
		int m = dc.SetStretchBltMode(COLORONCOLOR);
		StretchDIBits(dc, rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top, 0, 0, pHeader->biWidth, pHeader->biHeight, pData, (BITMAPINFO*)pHeader, DIB_RGB_COLORS, SRCCOPY);
		dc.SetStretchBltMode(m);
	}
	else
	{
		dc.FillRect(&rc, (HBRUSH)WHITE_BRUSH);
	}

	return 0;
}

static int Run(int nCmdShow = SW_SHOWDEFAULT)
{
	CMessageLoop theLoop;
	_Module.AddMessageLoop(&theLoop);

	CMainFrame frmMain;

	if (frmMain.CreateEx() == NULL)
	{
		ATLTRACE(_T("Main window creation failed!\n"));
		return 0;
	}

	frmMain.ShowWindow(nCmdShow);

	int nRet = theLoop.Run();

	_Module.RemoveMessageLoop();
	return nRet;
}

int WINAPI _tWinMain(HINSTANCE hInstance, HINSTANCE /*hPrevInstance*/, LPTSTR /*pCmdLine*/, int nCmdShow)
{
	INITCOMMONCONTROLSEX iccx;
	iccx.dwSize = sizeof(iccx);
	iccx.dwICC = ICC_COOL_CLASSES | ICC_BAR_CLASSES;
	InitCommonControlsEx(&iccx);

	OleInitialize(NULL);

	_Module.Init(NULL, hInstance);

	int nRet = Run(nCmdShow);

	_Module.Term();
	return nRet;
}