﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Text;
using System.Windows.Forms;
using ToupTek;
using System.Runtime.InteropServices;

namespace toupcamdemowinformcs3
{
    public partial class Form1 : Form
    {
        private delegate void DelegateOnError();
        private delegate void DelegateOnImage(int[] roundrobin);
        private delegate void DelegateOnExposure();
        private delegate void DelegateOnTempTint();
        private ToupCam toupcam_ = null;
        private Bitmap bmp1_ = null;
        private Bitmap bmp2_ = null;
        private int roundrobin_ = 2;
        private Object locker_ = new Object();
        private DelegateOnError everror_ = null;
        private DelegateOnImage evimage_ = null;
        private DelegateOnExposure evexposure_ = null;
        private DelegateOnTempTint evtemptint_ = null;

        private void OnEventError()
        {
            if (toupcam_ != null)
            {
                toupcam_.Close();
                toupcam_ = null;
            }
            MessageBox.Show("Error");
        }

        private void OnEventExposure()
        {
            if (toupcam_ != null)
            {
                uint nTime = 0;
                if (toupcam_.get_ExpoTime(out nTime))
                {
                    trackBar1.Value = (int)nTime;
                    label1.Text = (nTime / 1000).ToString() + " ms";
                }
            }
        }

        private void OnEventImage(int[] roundrobin)
        {
            lock(locker_)
            {
                if (roundrobin[0] == 1)
                    pictureBox1.Image = bmp1_;
                else
                    pictureBox1.Image = bmp2_;
                roundrobin_ = roundrobin[0];
            }
            pictureBox1.Invalidate();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button2.Enabled = false;
            button3.Enabled = false;
            trackBar1.Enabled = false;
            trackBar2.Enabled = false;
            trackBar3.Enabled = false;
            checkBox1.Enabled = false;
            comboBox1.Enabled = false;
        }

        /* these delegates are called by internal thread of toupcam.dll which is NOT the same of UI thread.
          * Why we use BeginInvoke, Please see:
          * http://msdn.microsoft.com/en-us/magazine/cc300429.aspx
          * http://msdn.microsoft.com/en-us/magazine/cc188732.aspx
          * http://stackoverflow.com/questions/1364116/avoiding-the-woes-of-invoke-begininvoke-in-cross-thread-winform-event-handling
         */
        
        void DelegateOnTempTintCallback(int nTemp, int nTint)
        {
            BeginInvoke(evtemptint_);
        }

        void DelegateOnExposureCallback()
        {
            BeginInvoke(evexposure_);
        }

        void DelegateOnDataCallback(IntPtr pData, ref ToupCam.BITMAPINFOHEADER header, bool bSnap)
        {
            if (pData == null)
            {
                /* error */
                BeginInvoke(everror_);
            }
            else if (bSnap)
            {
                Bitmap sbmp = new Bitmap(header.biWidth, header.biHeight, PixelFormat.Format24bppRgb);

                BitmapData bmpdata = sbmp.LockBits(new Rectangle(0, 0, sbmp.Width, sbmp.Height), ImageLockMode.WriteOnly, sbmp.PixelFormat);
                ToupCam.CopyMemory(bmpdata.Scan0, pData, header.biSizeImage);
                sbmp.UnlockBits(bmpdata);

                sbmp.Save("toupcamdemowinformcs3.jpg");
            }
            else
            {
                int[] roundrobin = new int[] { 1 };
                lock (locker_)
                {
                	/* use two round robin bitmap objects to hold the image data */
                    if (1 == roundrobin_)
                    {
                        BitmapData bmpdata = bmp2_.LockBits(new Rectangle(0, 0, header.biWidth, header.biHeight), ImageLockMode.WriteOnly, bmp2_.PixelFormat);
                        ToupCam.CopyMemory(bmpdata.Scan0, pData, header.biSizeImage);
                        bmp2_.UnlockBits(bmpdata);
                        roundrobin[0] = 2;
                    }
                    else
                    {
                        BitmapData bmpdata = bmp1_.LockBits(new Rectangle(0, 0, header.biWidth, header.biHeight), ImageLockMode.WriteOnly, bmp1_.PixelFormat);
                        ToupCam.CopyMemory(bmpdata.Scan0, pData, header.biSizeImage);
                        bmp1_.UnlockBits(bmpdata);
                    }
                }
                BeginInvoke(evimage_, roundrobin);
            }
        }

        private void OnStart(object sender, EventArgs e)
        {
            if (toupcam_ != null)
                return;

            ToupCam.InstanceV2[] arr = ToupCam.EnumV2();
            if (arr.Length <= 0)
            {
                MessageBox.Show("no device");
            }
            else
            {
                toupcam_ = new ToupCam();
                if (!toupcam_.Open(arr[0].id))
                {
                    toupcam_ = null;
                }
                else
                {
                    checkBox1.Enabled = true;
                    trackBar1.Enabled = true;
                    trackBar2.Enabled = true;
                    trackBar3.Enabled = true;
                    comboBox1.Enabled = true;
                    button2.Enabled = true;
                    button3.Enabled = true;
                    button2.ContextMenuStrip = null;
                    InitSnapContextMenuAndExpoTimeRange();

                    trackBar2.SetRange(2000, 15000);
                    trackBar3.SetRange(200, 2500);
                    OnEventTempTint();

                    uint resnum = toupcam_.ResolutionNumber;
                    uint eSize = 0;
                    if (toupcam_.get_eSize(out eSize))
                    {
                        for (uint i = 0; i < resnum; ++i)
                        {
                            int w = 0, h = 0;
                            if (toupcam_.get_Resolution(i, out w, out h))
                                comboBox1.Items.Add(w.ToString() + "*" + h.ToString());
                        }
                        comboBox1.SelectedIndex = (int)eSize;

                        int width = 0, height = 0;
                        if (toupcam_.get_Size(out width, out height))
                        {
                            bmp1_ = new Bitmap(width, height, PixelFormat.Format24bppRgb);
                            bmp2_ = new Bitmap(width, height, PixelFormat.Format24bppRgb);
                            everror_ = new DelegateOnError(OnEventError);
                            evexposure_ = new DelegateOnExposure(OnEventExposure);
                            evimage_ = new DelegateOnImage(OnEventImage);
                            evtemptint_ = new DelegateOnTempTint(OnEventTempTint);
                            toupcam_.put_ExpoCallback(new ToupCam.DelegateExposureCallback(DelegateOnExposureCallback));
                            if (!toupcam_.StartPushMode(new ToupTek.ToupCam.DelegateDataCallback(DelegateOnDataCallback)))
                                MessageBox.Show("failed to start device");
                            else
                            {
                                bool autoexpo = true;
                                toupcam_.get_AutoExpoEnable(out autoexpo);
                                checkBox1.Checked = autoexpo;
                                trackBar1.Enabled = !checkBox1.Checked;
                            }
                        }
                    }
                }
            }
        }

        private void SnapClickedHandler(object sender, ToolStripItemClickedEventArgs e)
        {
            int k = button2.ContextMenuStrip.Items.IndexOf(e.ClickedItem);
            if (k >= 0)
                toupcam_.Snap((uint)k);
        }

        private void InitSnapContextMenuAndExpoTimeRange()
        {
            if (toupcam_ == null)
                return;

            uint nMin = 0, nMax = 0, nDef = 0;
            if (toupcam_.get_ExpTimeRange(out nMin, out nMax, out nDef))
                trackBar1.SetRange((int)nMin, (int)nMax);
            OnEventExposure();

            if (toupcam_.StillResolutionNumber <= 0)
                return;
            
            button2.ContextMenuStrip = new ContextMenuStrip();
            button2.ContextMenuStrip.ItemClicked += new ToolStripItemClickedEventHandler(this.SnapClickedHandler);

            if (toupcam_.StillResolutionNumber < toupcam_.ResolutionNumber)
            {
                uint eSize = 0;
                if (toupcam_.get_eSize(out eSize))
                {
                    if (0 == eSize)
                    {
                        StringBuilder sb = new StringBuilder();
                        int w = 0, h = 0;
                        toupcam_.get_Resolution(eSize, out w, out h);
                        sb.Append(w);
                        sb.Append(" * ");
                        sb.Append(h);
                        button2.ContextMenuStrip.Items.Add(sb.ToString());
                        return;
                    }
                }
            }

            for (uint i = 0; i < toupcam_.ResolutionNumber; ++i)
            {
                StringBuilder sb = new StringBuilder();
                int w = 0, h = 0;
                toupcam_.get_Resolution(i, out w, out h);
                sb.Append(w);
                sb.Append(" * ");
                sb.Append(h);
                button2.ContextMenuStrip.Items.Add(sb.ToString());
            }
        }

        private void OnSnap(object sender, EventArgs e)
        {
            if (toupcam_ != null)
            {
                if (toupcam_.StillResolutionNumber <= 0)
                {
                    lock(locker_)
                    {
                        if (pictureBox1.Image != null)
                        {
                            pictureBox1.Image.Save("toupcamdemowinformcs3.jpg");
                        }
                    }
                }
                else
                {
                    if (button2.ContextMenuStrip != null)
                        button2.ContextMenuStrip.Show(Cursor.Position);
                }
            }
        }

        private void OnClosing(object sender, FormClosingEventArgs e)
        {
            if (toupcam_ != null)
            {
                toupcam_.Close();
                toupcam_ = null;
            }
        }

        private void OnSelectResolution(object sender, EventArgs e)
        {
            if (toupcam_ != null)
            {
                uint eSize = 0;
                if (toupcam_.get_eSize(out eSize))
                {
                    if (eSize != comboBox1.SelectedIndex)
                    {
                        button2.ContextMenuStrip = null;

                        toupcam_.Stop();
                        toupcam_.put_eSize((uint)comboBox1.SelectedIndex);

                        InitSnapContextMenuAndExpoTimeRange();
                        OnEventTempTint();

                        int width = 0, height = 0;
                        if (toupcam_.get_Size(out width, out height))
                        {
                            bmp1_ = new Bitmap(width, height, PixelFormat.Format24bppRgb);
                            bmp2_ = new Bitmap(width, height, PixelFormat.Format24bppRgb);
                            everror_ = new DelegateOnError(OnEventError);
                            evexposure_ = new DelegateOnExposure(OnEventExposure);
                            evimage_ = new DelegateOnImage(OnEventImage);
                            evtemptint_ = new DelegateOnTempTint(OnEventTempTint);
                            toupcam_.put_ExpoCallback(new ToupCam.DelegateExposureCallback(DelegateOnExposureCallback));
                            toupcam_.StartPushMode(new ToupTek.ToupCam.DelegateDataCallback(DelegateOnDataCallback));
                        }
                    }
                }
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (toupcam_ != null)
                toupcam_.put_AutoExpoEnable(checkBox1.Checked);
            trackBar1.Enabled = !checkBox1.Checked;
        }

        private void OnExpoValueChange(object sender, EventArgs e)
        {
            if (!checkBox1.Checked)
            {
                if (toupcam_ != null)
                {
                    uint n = (uint)trackBar1.Value;
                    toupcam_.put_ExpoTime(n);
                    label1.Text = (n / 1000).ToString() + " ms";
                }
            }
        }

        private void Form_SizeChanged(object sender, EventArgs e)
        {
            pictureBox1.Width = ClientRectangle.Right - button1.Bounds.Right - 20;
            pictureBox1.Height = ClientRectangle.Height - 8;
        }

        private void OnEventTempTint()
        {
            if (toupcam_ != null)
            {
                int nTemp = 0, nTint = 0;
                if (toupcam_.get_TempTint(out nTemp, out nTint))
                {
                    label2.Text = nTemp.ToString();
                    label3.Text = nTint.ToString();
                    trackBar2.Value = nTemp;
                    trackBar3.Value = nTint;
                }
            }
        }

        private void OnWhiteBalanceOnePush(object sender, EventArgs e)
        {
            if (toupcam_ != null)
                toupcam_.AwbOnePush(new ToupCam.DelegateTempTintCallback(DelegateOnTempTintCallback));
        }

        private void OnTempTintChanged(object sender, EventArgs e)
        {
            if (toupcam_ != null)
                toupcam_.put_TempTint(trackBar2.Value, trackBar3.Value);
            label2.Text = trackBar2.Value.ToString();
            label3.Text = trackBar3.Value.ToString();
        }
    }
}
